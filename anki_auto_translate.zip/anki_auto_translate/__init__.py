# __init__.py
from . import main
main.init_addon()