# config.py - Advanced configuration for Enhanced Auto Translate

# Service configurations
TRANSLATION_SERVICES_CONFIG = {
    "MyMemory": {
        "url": "https://api.mymemory.translated.net/get",
        "method": "GET",
        "free": True,
        "rate_limit": 1000,  # requests per day
        "requires_key": False,
        "timeout": 10
    },
    "LibreTranslate": {
        "url": "https://libretranslate.de/translate",
        "method": "POST", 
        "free": True,
        "rate_limit": 5,     # requests per minute
        "requires_key": False,
        "timeout": 10
    },
    "Google Translate (Free)": {
        "url": "https://translate.googleapis.com/translate_a/single",
        "method": "GET",
        "free": True,
        "rate_limit": 100,   # requests per hour (unofficial)
        "requires_key": False,
        "timeout": 8
    }
}

# Language mappings for different services
LANGUAGE_MAPPINGS = {
    "MyMemory": {
        "auto": "auto",
        "zh-CN": "zh-CN",
        "zh-TW": "zh-TW"
    },
    "LibreTranslate": {
        "auto": "auto", 
        "zh-CN": "zh",
        "zh-TW": "zh"
    },
    "Google Translate (Free)": {
        "auto": "auto",
        "zh-CN": "zh-cn", 
        "zh-TW": "zh-tw"
    }
}

# Advanced settings
ADVANCED_CONFIG = {
    "cache_max_size": 1000,          # Maximum cached translations
    "cache_expire_days": 30,         # Cache expiry in days
    "max_text_length": 5000,         # Maximum text length to translate
    "chunk_size": 1000,              # Split long text into chunks
    "retry_delay": 1.0,              # Delay between retries (seconds)
    "fallback_enabled": True,        # Enable service fallback
    "auto_detect_threshold": 0.8,    # Confidence threshold for auto-detection
    "clean_html": True,              # Remove HTML tags before translation
    "preserve_formatting": False,    # Try to preserve text formatting
    "show_service_in_result": True   # Show which service was used
}

# UI Configuration
UI_CONFIG = {
    "show_progress_bar": True,
    "show_field_selection": True,
    "show_cache_controls": True,
    "compact_mode": False,           # Compact UI layout
    "remember_window_size": True,
    "default_shortcut": "Ctrl+Space"
}

# Error messages
ERROR_MESSAGES = {
    "network_error": "Network connection failed. Please check your internet connection.",
    "service_unavailable": "Translation service is currently unavailable.",
    "rate_limit_exceeded": "Rate limit exceeded. Please try again later.",
    "text_too_long": "Text is too long for translation. Maximum length: {} characters.",
    "invalid_language": "Invalid language code: {}",
    "no_text": "No text to translate.",
    "same_language": "Source and destination languages are the same.",
    "cache_error": "Error accessing translation cache."
}
