# debug.py - Debug utilities for Enhanced Auto Translate

import os
import sys
import json
from datetime import datetime

def log_debug(message, level="INFO"):
    """Simple logging function"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"[{timestamp}] [{level}] {message}"
    
    # Try to write to log file
    try:
        log_dir = os.path.join(os.path.dirname(__file__), "..", "..", "logs")
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        log_file = os.path.join(log_dir, "auto_translate_debug.log")
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_message + "\n")
    except Exception as e:
        print(f"Logging error: {e}")
    
    # Also print to console if available
    print(log_message)

def check_dependencies():
    """Check if required modules are available"""
    required_modules = ["requests", "json", "hashlib", "re", "time"]
    missing_modules = []
    
    for module in required_modules:
        try:
            __import__(module)
            log_debug(f"Module {module}: OK")
        except ImportError:
            missing_modules.append(module)
            log_debug(f"Module {module}: MISSING", "ERROR")
    
    return missing_modules

def check_anki_environment():
    """Check if Anki modules are available"""
    anki_modules = ["aqt", "anki"]
    available_modules = []
    
    for module in anki_modules:
        try:
            __import__(module)
            available_modules.append(module)
            log_debug(f"Anki module {module}: Available")
        except ImportError:
            log_debug(f"Anki module {module}: Not available (normal outside Anki)")
    
    return available_modules

def validate_config():
    """Validate addon configuration"""
    try:
        config_file = os.path.join(os.path.dirname(__file__), "meta.json")
        if os.path.exists(config_file):
            with open(config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            
            log_debug("Configuration loaded successfully")
            log_debug(f"Config: {json.dumps(config, indent=2)}")
            return True
        else:
            log_debug("Configuration file not found", "ERROR")
            return False
    except Exception as e:
        log_debug(f"Configuration validation error: {e}", "ERROR")
        return False

def test_translation_services():
    """Test if translation services are reachable"""
    try:
        import requests
        services = [
            "https://api.mymemory.translated.net/get",
            "https://libretranslate.de/translate", 
            "https://translate.googleapis.com/translate_a/single"
        ]
        
        for service in services:
            try:
                response = requests.get(service, timeout=5)
                log_debug(f"Service {service}: Status {response.status_code}")
            except Exception as e:
                log_debug(f"Service {service}: Error - {e}", "WARNING")
                
    except ImportError:
        log_debug("Requests module not available for service testing", "WARNING")

def run_debug_check():
    """Run complete debug check"""
    log_debug("=== Enhanced Auto Translate Debug Check ===")
    log_debug(f"Python version: {sys.version}")
    log_debug(f"Platform: {sys.platform}")
    log_debug(f"Working directory: {os.getcwd()}")
    log_debug(f"Script location: {os.path.dirname(__file__)}")
    
    log_debug("--- Checking Dependencies ---")
    missing = check_dependencies()
    if missing:
        log_debug(f"Missing modules: {missing}", "WARNING")
    else:
        log_debug("All required modules available")
    
    log_debug("--- Checking Anki Environment ---") 
    available = check_anki_environment()
    
    log_debug("--- Validating Configuration ---")
    config_ok = validate_config()
    
    log_debug("--- Testing Translation Services ---")
    test_translation_services()
    
    log_debug("=== Debug Check Complete ===")
    
    return {
        "dependencies_ok": len(missing) == 0,
        "config_ok": config_ok,
        "anki_available": len(available) > 0
    }

if __name__ == "__main__":
    run_debug_check()
