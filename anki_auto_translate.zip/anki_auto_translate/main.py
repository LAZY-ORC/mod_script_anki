# main.py - Enhanced Auto Translate with multiple services and better features

import aqt
from aqt.qt import (QWidget, QHBoxLayout, QVBoxLayout, QLabel, QComboBox, 
                    QPushButton, QShortcut, QKeySequence, QProgressBar, 
                    QMessageBox, QCheckBox, QGroupBox)
from aqt import mw, gui_hooks
import requests
import json
import hashlib
import time
import re
from urllib.parse import quote

# --- Version compatibility ---
try: from aqt.i18n import tr as _
except:
    try: from anki.lang import _
    except: from aqt.utils import _

# --- CONSTANTS AND CONFIGURATION ---
ADDON_PACKAGE_NAME = "anki_auto_translate"

# Multiple translation services
TRANSLATION_SERVICES = {
    "MyMemory": {
        "url": "https://api.mymemory.translated.net/get",
        "free": True,
        "requires_key": False
    },
    "LibreTranslate": {
        "url": "https://libretranslate.de/translate",
        "free": True,
        "requires_key": False
    },
    "Google Translate (Free)": {
        "url": "https://translate.googleapis.com/translate_a/single",
        "free": True,
        "requires_key": False
    }
}

LANGUAGES = {
    "Auto Detect": "auto",
    "English": "en", "Vietnamese": "vi", "Japanese": "ja", "Korean": "ko",
    "Chinese (Simplified)": "zh-CN", "Chinese (Traditional)": "zh-TW",
    "French": "fr", "German": "de", "Spanish": "es", "Russian": "ru",
    "Italian": "it", "Portuguese": "pt", "Dutch": "nl", "Arabic": "ar",
    "Hindi": "hi", "Thai": "th", "Indonesian": "id", "Malay": "ms"
}

# Cache for translations
TRANSLATION_CACHE = {}

def get_config():
    config = mw.addonManager.getConfig(ADDON_PACKAGE_NAME)
    if config is None:
        return {
            "src_lang": "en", 
            "dest_lang": "vi",
            "service": "MyMemory",
            "auto_detect": True,
            "cache_enabled": True,
            "retry_count": 2
        }
    return config

def write_config(config):
    mw.addonManager.writeConfig(ADDON_PACKAGE_NAME, config)

def get_cache_key(text, src_lang, dest_lang, service):
    """Generate cache key for translation"""
    content = f"{text}|{src_lang}|{dest_lang}|{service}"
    return hashlib.md5(content.encode()).hexdigest()

def clean_text(text):
    """Clean HTML tags and extra whitespace from text"""
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def detect_language(text):
    """Simple language detection based on character patterns"""
    if not text:
        return "en"
    
    # Check for Asian characters
    if re.search(r'[\u4e00-\u9fff]', text):  # Chinese
        return "zh-CN"
    if re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text):  # Japanese
        return "ja"
    if re.search(r'[\uac00-\ud7af]', text):  # Korean
        return "ko"
    if re.search(r'[\u0e00-\u0e7f]', text):  # Thai
        return "th"
    if re.search(r'[\u0600-\u06ff]', text):  # Arabic
        return "ar"
    
    # Check for Vietnamese diacritics
    vietnamese_chars = r'[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]'
    if re.search(vietnamese_chars, text, re.IGNORECASE):
        return "vi"
    
    # Default to English for Latin scripts
    return "en"

# --- ENHANCED TRANSLATION LOGIC ---
def translate_with_mymemory(text, src_lang, dest_lang):
    """Translate using MyMemory API"""
    url = "https://api.mymemory.translated.net/get"
    params = {"q": text, "langpair": f"{src_lang}|{dest_lang}"}
    
    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()
    data = response.json()
    
    translated_text = data.get('responseData', {}).get('translatedText')
    if not translated_text:
        raise Exception("No translation result")
    
    return translated_text

def translate_with_libretranslate(text, src_lang, dest_lang):
    """Translate using LibreTranslate API"""
    url = "https://libretranslate.de/translate"
    data = {
        "q": text,
        "source": src_lang if src_lang != "auto" else "auto",
        "target": dest_lang,
        "format": "text"
    }
    
    response = requests.post(url, data=data, timeout=10)
    response.raise_for_status()
    result = response.json()
    
    translated_text = result.get('translatedText')
    if not translated_text:
        raise Exception("No translation result")
    
    return translated_text

def translate_with_google_free(text, src_lang, dest_lang):
    """Translate using Google Translate (free, unofficial)"""
    if src_lang == "auto":
        src_lang = "auto"
    
    url = "https://translate.googleapis.com/translate_a/single"
    params = {
        "client": "gtx",
        "sl": src_lang,
        "tl": dest_lang,
        "dt": "t",
        "q": text
    }
    
    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()
    result = response.json()
    
    if result and result[0]:
        translated_text = "".join([sentence[0] for sentence in result[0] if sentence[0]])
        return translated_text
    
    raise Exception("No translation result")

def auto_translate(text, src_lang, dest_lang, service="MyMemory", use_cache=True, retry_count=2):
    """Enhanced translation with multiple services and error handling"""
    if not text or not text.strip():
        return ""
    
    # Clean text
    cleaned_text = clean_text(text)
    if not cleaned_text:
        return ""
    
    # Auto-detect language if needed
    if src_lang == "auto":
        src_lang = detect_language(cleaned_text)
    
    # Check cache first
    if use_cache:
        cache_key = get_cache_key(cleaned_text, src_lang, dest_lang, service)
        if cache_key in TRANSLATION_CACHE:
            return TRANSLATION_CACHE[cache_key]
    
    # Translation services mapping
    translate_functions = {
        "MyMemory": translate_with_mymemory,
        "LibreTranslate": translate_with_libretranslate,
        "Google Translate (Free)": translate_with_google_free
    }
    
    # Try primary service with retries
    for attempt in range(retry_count + 1):
        try:
            if service in translate_functions:
                translated_text = translate_functions[service](cleaned_text, src_lang, dest_lang)
                
                # Cache successful translation
                if use_cache:
                    TRANSLATION_CACHE[cache_key] = translated_text
                
                return translated_text
            else:
                raise Exception(f"Unknown service: {service}")
                
        except Exception as e:
            if attempt < retry_count:
                time.sleep(1)  # Wait before retry
                continue
            
            # Try fallback services
            for fallback_service, func in translate_functions.items():
                if fallback_service != service:
                    try:
                        translated_text = func(cleaned_text, src_lang, dest_lang)
                        
                        # Cache successful translation
                        if use_cache:
                            TRANSLATION_CACHE[cache_key] = translated_text
                        
                        return f"{translated_text} [via {fallback_service}]"
                    except:
                        continue
            
            # All services failed
            return _("[Translation Error: {}]").format(str(e))

# --- ENHANCED EVENT HANDLER FUNCTION ---
def on_translate_button_clicked(editor):
    note = editor.note
    if not note: 
        return
    
    # Get selected fields
    src_field_name = editor.src_field_combo.currentText()
    dest_field_name = editor.dest_field_combo.currentText()
    
    if src_field_name == dest_field_name:
        QMessageBox.warning(editor.web, _("Error"), _("Source and destination fields cannot be the same!"))
        return
    
    text_to_translate = note[src_field_name]
    if not text_to_translate or not text_to_translate.strip():
        QMessageBox.information(editor.web, _("Info"), _("Source field is empty!"))
        return
    
    # Get translation settings
    src_lang = editor.source_lang_combo.currentData()
    dest_lang = editor.dest_lang_combo.currentData()
    service = editor.service_combo.currentText()
    
    # Show progress
    editor.progress_bar.setVisible(True)
    editor.progress_bar.setRange(0, 0)  # Indeterminate progress
    editor.translate_button.setEnabled(False)
    editor.translate_button.setText(_("Translating..."))
    
    try:
        config = get_config()
        translated_text = auto_translate(
            text_to_translate, 
            src_lang, 
            dest_lang, 
            service,
            config.get("cache_enabled", True),
            config.get("retry_count", 2)
        )
        
        # Check if translation was successful
        if translated_text and not translated_text.startswith("[Translation Error"):
            note[dest_field_name] = translated_text
            editor.loadNote()
            
            # Save configuration
            config.update({
                "src_lang": src_lang,
                "dest_lang": dest_lang,
                "service": service,
                "src_field": src_field_name,
                "dest_field": dest_field_name
            })
            write_config(config)
            
            # Show success message briefly
            editor.translate_button.setText(_("Success!"))
            mw.app.processEvents()
            time.sleep(0.5)
        else:
            QMessageBox.warning(editor.web, _("Translation Error"), translated_text)
            
    except Exception as e:
        QMessageBox.critical(editor.web, _("Error"), _("Translation failed: {}").format(str(e)))
    
    finally:
        # Reset UI
        editor.progress_bar.setVisible(False)
        editor.translate_button.setEnabled(True)
        editor.translate_button.setText(_("Translate"))

def on_field_changed(editor):
    """Update field display when selection changes"""
    if not hasattr(editor, 'src_field_combo') or not hasattr(editor, 'dest_field_combo'):
        return
        
    src_field = editor.src_field_combo.currentText()
    dest_field = editor.dest_field_combo.currentText()
    
    # Update labels
    if hasattr(editor, 'src_label'):
        editor.src_label.setText(_("From <b>{}</b>:").format(src_field))
    if hasattr(editor, 'dest_label'):
        editor.dest_label.setText(_("To <b>{}</b>:").format(dest_field))

# --- ENHANCED UI FOR EDITOR ---
def add_translate_ui_to_editor(js, note, editor):
    field_names = list(note.keys())
    if len(field_names) < 2: 
        return js
    if hasattr(editor, "source_lang_combo"): 
        return js

    config = get_config()
    
    # Main container
    main_container = QWidget()
    main_layout = QVBoxLayout(main_container)
    main_layout.setContentsMargins(5, 5, 5, 5)
    main_layout.setSpacing(8)
    
    # Translation settings group
    settings_group = QGroupBox(_("Translation Settings"))
    settings_layout = QVBoxLayout(settings_group)
    
    # Field selection row
    field_row = QWidget()
    field_layout = QHBoxLayout(field_row)
    field_layout.setContentsMargins(0, 0, 0, 0)
    
    # Source field selection
    field_layout.addWidget(QLabel(_("From field:")))
    editor.src_field_combo = QComboBox()
    editor.src_field_combo.addItems(field_names)
    saved_src_field = config.get("src_field", field_names[0])
    if saved_src_field in field_names:
        editor.src_field_combo.setCurrentText(saved_src_field)
    field_layout.addWidget(editor.src_field_combo)
    
    field_layout.addWidget(QLabel(_("To field:")))
    editor.dest_field_combo = QComboBox()
    editor.dest_field_combo.addItems(field_names)
    saved_dest_field = config.get("dest_field", field_names[1] if len(field_names) > 1 else field_names[0])
    if saved_dest_field in field_names:
        editor.dest_field_combo.setCurrentText(saved_dest_field)
    field_layout.addWidget(editor.dest_field_combo)
    
    # Connect field change events
    editor.src_field_combo.currentTextChanged.connect(lambda: on_field_changed(editor))
    editor.dest_field_combo.currentTextChanged.connect(lambda: on_field_changed(editor))
    
    settings_layout.addWidget(field_row)
    
    # Language selection row
    lang_row = QWidget()
    lang_layout = QHBoxLayout(lang_row)
    lang_layout.setContentsMargins(0, 0, 0, 0)
    
    # Source language
    editor.src_label = QLabel(_("From <b>{}</b>:").format(editor.src_field_combo.currentText()))
    editor.source_lang_combo = QComboBox()
    for name, code in LANGUAGES.items():
        editor.source_lang_combo.addItem(name, code)
    index = editor.source_lang_combo.findData(config.get("src_lang", "auto"))
    if index != -1: 
        editor.source_lang_combo.setCurrentIndex(index)
    
    lang_layout.addWidget(editor.src_label)
    lang_layout.addWidget(editor.source_lang_combo)
    
    # Destination language
    editor.dest_label = QLabel(_("To <b>{}</b>:").format(editor.dest_field_combo.currentText()))
    editor.dest_lang_combo = QComboBox()
    for name, code in LANGUAGES.items():
        if code != "auto":  # Don't allow auto-detect for destination
            editor.dest_lang_combo.addItem(name, code)
    index = editor.dest_lang_combo.findData(config.get("dest_lang", "vi"))
    if index != -1: 
        editor.dest_lang_combo.setCurrentIndex(index)
    
    lang_layout.addWidget(editor.dest_label)
    lang_layout.addWidget(editor.dest_lang_combo)
    
    settings_layout.addWidget(lang_row)
    
    # Service selection row
    service_row = QWidget()
    service_layout = QHBoxLayout(service_row)
    service_layout.setContentsMargins(0, 0, 0, 0)
    
    service_layout.addWidget(QLabel(_("Translation service:")))
    editor.service_combo = QComboBox()
    for service_name in TRANSLATION_SERVICES.keys():
        editor.service_combo.addItem(service_name)
    saved_service = config.get("service", "MyMemory")
    if saved_service in TRANSLATION_SERVICES:
        editor.service_combo.setCurrentText(saved_service)
    service_layout.addWidget(editor.service_combo)
    
    # Add cache checkbox
    editor.cache_checkbox = QCheckBox(_("Enable translation cache"))
    editor.cache_checkbox.setChecked(config.get("cache_enabled", True))
    service_layout.addWidget(editor.cache_checkbox)
    
    service_layout.addStretch()
    settings_layout.addWidget(service_row)
    
    main_layout.addWidget(settings_group)
    
    # Action row
    action_row = QWidget()
    action_layout = QHBoxLayout(action_row)
    action_layout.setContentsMargins(0, 0, 0, 0)
    
    # Translate button
    editor.translate_button = QPushButton(_("Translate"))
    editor.translate_button.setToolTip(_("Translate text (Ctrl+Space)"))
    editor.translate_button.clicked.connect(lambda _, ed=editor: on_translate_button_clicked(ed))
    action_layout.addWidget(editor.translate_button)
    
    # Progress bar
    editor.progress_bar = QProgressBar()
    editor.progress_bar.setVisible(False)
    editor.progress_bar.setMaximumHeight(20)
    action_layout.addWidget(editor.progress_bar)
    
    # Clear cache button
    clear_cache_button = QPushButton(_("Clear Cache"))
    clear_cache_button.setToolTip(_("Clear translation cache"))
    clear_cache_button.clicked.connect(lambda: clear_translation_cache())
    action_layout.addWidget(clear_cache_button)
    
    action_layout.addStretch()
    main_layout.addWidget(action_row)
    
    # Keyboard shortcut
    shortcut = QShortcut(QKeySequence("Ctrl+Space"), editor.web)
    shortcut.activated.connect(lambda: on_translate_button_clicked(editor))
    
    # Add to editor
    main_editor_layout = editor.web.parent().layout()
    main_editor_layout.insertWidget(1, main_container)
    
    return js

def clear_translation_cache():
    """Clear translation cache"""
    global TRANSLATION_CACHE
    TRANSLATION_CACHE.clear()
    QMessageBox.information(None, _("Cache Cleared"), _("Translation cache has been cleared."))

# --- INITIALIZE ADD-ON ---
def init_addon():
    gui_hooks.editor_will_load_note.append(add_translate_ui_to_editor)

# Start the addon
if __name__ != "__main__":
    init_addon()