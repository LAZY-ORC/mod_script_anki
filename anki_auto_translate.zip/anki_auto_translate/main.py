# main.py - Final version, also translates field names for basic note types

import aqt
from aqt.qt import *
from aqt import mw, gui_hooks
import requests

# --- Version compatibility ---
try: from aqt.i18n import tr as _
except:
    try: from anki.lang import _
    except: from aqt.utils import _

# --- CONSTANTS AND CONFIGURATION ---
ADDON_PACKAGE_NAME = "anki_auto_translate"
TRANSLATE_API_URL = "https://api.mymemory.translated.net/get"
LANGUAGES = {
    "English": "en", "Vietnamese": "vi", "Japanese": "ja", "Korean": "ko",
    "Chinese (Simplified)": "zh-CN", "French": "fr", "German": "de",
    "Spanish": "es", "Russian": "ru",
}

def get_config():
    config = mw.addonManager.getConfig(ADDON_PACKAGE_NAME)
    if config is None:
        return {"src_lang": "en", "dest_lang": "vi"}
    return config

def write_config(config):
    mw.addonManager.writeConfig(ADDON_PACKAGE_NAME, config)

# --- TRANSLATION LOGIC ---
def auto_translate(text, src_lang, dest_lang):
    params = {"q": text, "langpair": f"{src_lang}|{dest_lang}"}
    try:
        response = requests.get(TRANSLATE_API_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        translated_text = data.get('responseData', {}).get('translatedText')
        return translated_text if translated_text else _("[Error: No result]")
    except Exception as e:
        return _("[Translation Error: {}]").format(e)

# --- EVENT HANDLER FUNCTION ---
def on_translate_button_clicked(editor):
    note = editor.note
    if not note: return
    field_names = list(note.keys())
    if len(field_names) < 2: return
    src_field_name, dest_field_name = field_names[0], field_names[1]
    text_to_translate = note[src_field_name]
    if not text_to_translate: return
    src_lang = editor.source_lang_combo.currentData()
    dest_lang = editor.dest_lang_combo.currentData()
    translated_text = auto_translate(text_to_translate, src_lang, dest_lang)
    note[dest_field_name] = translated_text
    editor.loadNote()
    write_config({"src_lang": src_lang, "dest_lang": dest_lang})

# --- ADD TRANSLATE UI TO EDITOR ---
def add_translate_ui_to_editor(js, note, editor):
    field_names = list(note.keys())
    if len(field_names) < 2: return js
    if hasattr(editor, "source_lang_combo"): return js

    config = get_config()
    container = QWidget()
    layout = QHBoxLayout(container)
    layout.setContentsMargins(0, 5, 0, 5)

    # --- UPGRADE: Translate field names "Front" and "Back" ---
    src_actual_name = field_names[0]
    dest_actual_name = field_names[1]

    # Check if the field name is a variant of "Front"
    if src_actual_name.lower() in ["front", "mặt trước"]:
        src_display_name = _("Front") # System translation for "Front"
    else:
        src_display_name = src_actual_name # Keep custom field name

    # Check if the field name is a variant of "Back"
    if dest_actual_name.lower() in ["back", "mặt sau"]:
        dest_display_name = _("Back") # System translation for "Back"
    else:
        dest_display_name = dest_actual_name # Keep custom field name

    src_label = QLabel(_("Translate from <b>{}</b>:").format(src_display_name))
    editor.source_lang_combo = QComboBox()
    for name, code in LANGUAGES.items():
        editor.source_lang_combo.addItem(name, code)
    index = editor.source_lang_combo.findData(config.get("src_lang", "en"))
    if index != -1: editor.source_lang_combo.setCurrentIndex(index)

    dest_label = QLabel(_("to <b>{}</b>:").format(dest_display_name))
    editor.dest_lang_combo = QComboBox()
    for name, code in LANGUAGES.items():
        editor.dest_lang_combo.addItem(name, code)
    index = editor.dest_lang_combo.findData(config.get("dest_lang", "vi"))
    if index != -1: editor.dest_lang_combo.setCurrentIndex(index)

    translate_button = QPushButton(_("Translate"))
    translate_button.setToolTip(_("Translate content from the first field to the second field"))
    translate_button.clicked.connect(lambda _, ed=editor: on_translate_button_clicked(ed))

    layout.addWidget(src_label)
    layout.addWidget(editor.source_lang_combo)
    layout.addWidget(dest_label)
    layout.addWidget(editor.dest_lang_combo)
    layout.addWidget(translate_button)
    layout.addStretch()

    main_layout = editor.web.parent().layout()
    main_layout.insertWidget(1, container)
    
    return js

# --- INITIALIZE ADD-ON ---
def init_addon():
    gui_hooks.editor_will_load_note.append(add_translate_ui_to_editor)