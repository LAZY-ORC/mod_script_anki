# test_translation.py - Simple test for translation functions

import requests
import re
import hashlib
import time

# Test translation functions without Anki dependencies

def clean_text(text):
    """Clean HTML tags and extra whitespace from text"""
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def detect_language(text):
    """Simple language detection based on character patterns"""
    if not text:
        return "en"
    
    # Check for Asian characters
    if re.search(r'[\u4e00-\u9fff]', text):  # Chinese
        return "zh-CN"
    if re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text):  # Japanese
        return "ja"
    if re.search(r'[\uac00-\ud7af]', text):  # Korean
        return "ko"
    if re.search(r'[\u0e00-\u0e7f]', text):  # Thai
        return "th"
    if re.search(r'[\u0600-\u06ff]', text):  # Arabic
        return "ar"
    
    # Check for Vietnamese diacritics
    vietnamese_chars = r'[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]'
    if re.search(vietnamese_chars, text, re.IGNORECASE):
        return "vi"
    
    return "en"

def translate_with_mymemory(text, src_lang, dest_lang):
    """Test MyMemory translation"""
    url = "https://api.mymemory.translated.net/get"
    params = {"q": text, "langpair": f"{src_lang}|{dest_lang}"}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        translated_text = data.get('responseData', {}).get('translatedText')
        if not translated_text:
            raise Exception("No translation result")
        
        return translated_text
    except Exception as e:
        return f"Error: {e}"

def translate_with_libretranslate(text, src_lang, dest_lang):
    """Test LibreTranslate translation"""
    url = "https://libretranslate.de/translate"
    data = {
        "q": text,
        "source": src_lang if src_lang != "auto" else "auto",
        "target": dest_lang,
        "format": "text"
    }
    
    try:
        response = requests.post(url, data=data, timeout=10)
        response.raise_for_status()
        result = response.json()
        
        translated_text = result.get('translatedText')
        if not translated_text:
            raise Exception("No translation result")
        
        return translated_text
    except Exception as e:
        return f"Error: {e}"

# Test cases
if __name__ == "__main__":
    test_texts = [
        ("Hello world", "en", "vi"),
        ("Xin chào thế giới", "vi", "en"),
        ("こんにちは世界", "ja", "en"),
        ("안녕하세요 세계", "ko", "en"),
        ("你好世界", "zh-CN", "en")
    ]
    
    print("=== Testing Language Detection ===")
    for text, expected_lang, _ in test_texts:
        detected = detect_language(text)
        print(f"Text: '{text}' -> Detected: {detected} (Expected: {expected_lang})")
    
    print("\n=== Testing MyMemory Translation ===")
    for text, src_lang, dest_lang in test_texts[:2]:  # Test first 2 only
        result = translate_with_mymemory(text, src_lang, dest_lang)
        print(f"'{text}' ({src_lang} -> {dest_lang}): {result}")
        time.sleep(1)  # Rate limiting
    
    print("\n=== Testing LibreTranslate ===")
    for text, src_lang, dest_lang in test_texts[:2]:  # Test first 2 only
        result = translate_with_libretranslate(text, src_lang, dest_lang)
        print(f"'{text}' ({src_lang} -> {dest_lang}): {result}")
        time.sleep(2)  # Rate limiting
    
    print("\n=== Testing HTML Cleaning ===")
    html_text = "<p>Hello <b>world</b>!</p>"
    cleaned = clean_text(html_text)
    print(f"Original: {html_text}")
    print(f"Cleaned: {cleaned}")
