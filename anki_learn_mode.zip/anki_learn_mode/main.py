# multiple_choice_mode.py
import random
from aqt import mw
from aqt.qt import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QButtonGroup,
    QRadioButton,
)
from aqt.utils import showInfo, tooltip

# Thay đổi import này
from .config_dialog import ConfigDialog

class QuizDialog(QDialog):
    # ... (The entire code of the QuizDialog class from the previous answer) ...
    """Dialog displays the quiz."""
    def __init__(self, questions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Learn Mode - Test")
        self.setMinimumSize(400, 300)
        self.layout = QVBoxLayout(self)

        self.questions = questions
        self.all_answers = list(set([a for q, a in self.questions]))
        self.current_q_index = 0
        self.score = 0

        self.question_label = QLabel()
        self.question_label.setWordWrap(True)
        self.layout.addWidget(self.question_label)

        self.options_group = QButtonGroup(self)
        self.radio_buttons = [QRadioButton() for _ in range(4)]
        for rb in self.radio_buttons:
            self.layout.addWidget(rb)
            self.options_group.addButton(rb)

        self.feedback_label = QLabel()
        self.layout.addWidget(self.feedback_label)

        self.button_layout = QHBoxLayout()
        self.submit_button = QPushButton("Answer")
        self.submit_button.clicked.connect(self.check_answer)
        self.next_button = QPushButton("Continue")
        self.next_button.clicked.connect(self.next_question)
        self.button_layout.addWidget(self.submit_button)
        self.button_layout.addWidget(self.next_button)
        self.layout.addLayout(self.button_layout)

        self.show_question()

    def show_question(self):
        if self.current_q_index >= len(self.questions):
            self.show_final_score()
            return

        # Reset interface for new question
        self.feedback_label.setText("")
        self.submit_button.show()
        self.next_button.hide()
        for rb in self.radio_buttons:
            rb.setEnabled(True)
            rb.setStyleSheet("") # Reset color
        self.options_group.setExclusive(False) # Temporarily enable deselect
        for rb in self.radio_buttons:
            rb.setChecked(False)
        self.options_group.setExclusive(True) # Turn on select mode 1 again

        # Get current question and answer
        q_text, correct_answer = self.questions[self.current_q_index]
        self.question_label.setText(f"<b>Question {self.current_q_index + 1}/{len(self.questions)}:</b><br>{q_text}")

        # Make selections
        options = {correct_answer}
        possible_wrong_answers = [ans for ans in self.all_answers if ans != correct_answer]
        
        num_to_sample = min(len(possible_wrong_answers), 3)
        if num_to_sample > 0:
            options.update(random.sample(possible_wrong_answers, num_to_sample))
        
        while len(options) < min(4, len(self.all_answers)):
             options.add(random.choice(self.all_answers))
             
        options_list = list(options)
        random.shuffle(options_list)

        # Hiển thị các lựa chọn
        for i, rb in enumerate(self.radio_buttons):
            if i < len(options_list):
                rb.setText(options_list[i])
                rb.show()
            else:
                rb.hide()

    def check_answer(self):
        checked_button = self.options_group.checkedButton()
        if not checked_button:
            tooltip("Please select one answer.")
            return

        user_answer = checked_button.text()
        _, correct_answer = self.questions[self.current_q_index]

        for rb in self.radio_buttons:
            rb.setEnabled(False)

        if user_answer == correct_answer:
            self.score += 1
            self.feedback_label.setText("<b style='color: green;'>Amazing!</b>")
            checked_button.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.feedback_label.setText(f"<b style='color: red;'>Wrong!</b> The correct answer is: <b>{correct_answer}</b>")
            checked_button.setStyleSheet("color: red;")
            for rb in self.radio_buttons:
                if rb.text() == correct_answer:
                    rb.setStyleSheet("color: green; font-weight: bold;")
                    break

        self.submit_button.hide()
        self.next_button.show()
        self.next_button.setFocus()

    def next_question(self):
        self.current_q_index += 1
        self.show_question()

    def show_final_score(self):
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            if item.widget():
                item.widget().setParent(None)
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().setParent(None)
                item.layout().deleteLater()
        
        score_text = f"Finished!\nYour score: {self.score}/{len(self.questions)}"
        self.layout.addWidget(QLabel(score_text))
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        self.layout.addWidget(close_button)


def on_multiple_choice_triggered(browser):
    # ... (The entire code of the on_learn_mode_triggered function from the previous answer, renamed and slightly modified) ...
    selected_nids = browser.selected_notes()
    if not selected_nids:
        showInfo("Select some tabs in your browser to get started.")
        return

    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    
    # Limit the number of questions to the number of cards selected.
    max_notes = len(selected_nids)
    if max_notes < 4:
        showInfo(f"At least 4 cards are required to create a quiz. You have only selected {max_notes} cards.")
        return

    config_dialog = ConfigDialog(field_names, browser, max_num=max_notes)
    if not config_dialog.exec():
        return

    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        if q_field in note and a_field in note and note[q_field].strip() and note[a_field].strip():
            questions.append((note[q_field], note[a_field]))

    if len(questions) < 4:
        showInfo(f"Unable to create quiz. Only {len(questions)} valid tags found (at least 4 required). Make sure the fields you select are not empty.")
        return

    quiz_dialog = QuizDialog(questions, mw)
    quiz_dialog.exec()