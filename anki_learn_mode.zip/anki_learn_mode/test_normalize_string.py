# Test file to verify normalize_string function works correctly
# Run this outside of Anki to test the function

from unicodedata import normalize

def normalize_string(s: str, case_sensitive: bool = False) -> str:
    """Enhanced string normalization."""
    normalized = normalize("NFC", s).strip()
    if not case_sensitive:
        normalized = normalized.lower()
    return normalized

# Test cases
def test_normalize_string():
    print("Testing normalize_string function...")
    
    # Test case sensitive = False (default)
    result1 = normalize_string("Hello World")
    expected1 = "hello world"
    print(f"Test 1: normalize_string('Hello World') = '{result1}' (expected: '{expected1}')")
    assert result1 == expected1, f"Failed: got '{result1}', expected '{expected1}'"
    
    # Test case sensitive = True
    result2 = normalize_string("Hello World", case_sensitive=True)
    expected2 = "Hello World"
    print(f"Test 2: normalize_string('Hello World', case_sensitive=True) = '{result2}' (expected: '{expected2}')")
    assert result2 == expected2, f"Failed: got '{result2}', expected '{expected2}'"
    
    # Test with whitespace
    result3 = normalize_string("  Hello World  ", case_sensitive=False)
    expected3 = "hello world"
    print(f"Test 3: normalize_string('  Hello World  ') = '{result3}' (expected: '{expected3}')")
    assert result3 == expected3, f"Failed: got '{result3}', expected '{expected3}'"
    
    print("✅ All tests passed!")

if __name__ == "__main__":
    test_normalize_string()
