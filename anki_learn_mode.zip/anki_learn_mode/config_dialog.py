# config_dialog.py
from aqt.qt import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QComboBox,
    QSpinBox,
    QDialogButtonBox,
)
from aqt.utils import showWarning

class ConfigDialog(QDialog):
    """Dialog for user to select fields and number of questions."""
    def __init__(self, field_names, parent=None, default_num=10, max_num=100):
        super().__init__(parent)
        self.setWindowTitle("Configure Learn Mode")
        self.layout = QVBoxLayout(self)

        # Select question field
        self.layout.addWidget(QLabel("Select Fields for Question (Front):"))
        self.q_field_combo = QComboBox()
        self.q_field_combo.addItems(field_names)
        self.layout.addWidget(self.q_field_combo)

        # Select answer field
        self.layout.addWidget(QLabel("Select Field for Answer (Back):"))
        self.a_field_combo = QComboBox()
        self.a_field_combo.addItems(field_names)
        if len(field_names) > 1:
            self.a_field_combo.setCurrentIndex(1)
        self.layout.addWidget(self.a_field_combo)

        # Chọn số lượng câu hỏi
        self.layout.addWidget(QLabel("Number of cards to practice:"))
        self.num_questions_spin = QSpinBox()
        self.num_questions_spin.setMinimum(1)
        self.num_questions_spin.setMaximum(max_num)
        self.num_questions_spin.setValue(default_num)
        self.layout.addWidget(self.num_questions_spin)

        # Nút OK và Cancel
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.layout.addWidget(self.button_box)

        self.config = None

    def accept(self):
        q_field = self.q_field_combo.currentText()
        a_field = self.a_field_combo.currentText()
        if q_field == a_field:
            showWarning("Question and answer fields cannot be duplicated.")
            return

        self.config = {
            "q_field": q_field,
            "a_field": a_field,
            "num_questions": self.num_questions_spin.value()
        }
        super().accept()