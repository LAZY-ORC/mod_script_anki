# written_mode.py
import random
from unicodedata import normalize

from aqt import mw
from aqt.qt import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
)
from aqt.utils import showInfo

from .config_dialog import ConfigDialog

# String normalization function for easier comparison (remove accents, uppercase)
def normalize_string(s: str) -> str:
    # NFC: Normalize character combinations (e.g., e + ´ -> é)
    # lower: Convert to lowercase
    # strip: Remove leading spaces
    return normalize("NFC", s).lower().strip()

class WrittenDialog(QDialog):
    """Dialog for "Write" learning mode."""
    def __init__(self, questions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Learn Mode - Write")
        self.setMinimumSize(450, 250)
        self.layout = QVBoxLayout(self)

        self.all_questions = questions
        self.remaining_questions = list(self.all_questions) # List of questions to answer
        random.shuffle(self.remaining_questions)
        
        self.correct_count = 0
        self.mistakes = [] # Save wrong answers for review

        # Widgets
        self.progress_label = QLabel()
        self.prompt_label = QLabel()
        self.prompt_label.setWordWrap(True)
        self.answer_input = QLineEdit()
        self.feedback_label = QLabel()
        self.correct_answer_label = QLabel()
        self.correct_answer_label.setWordWrap(True)
        self.submit_button = QPushButton("Answer")

        # Add to layout
        self.layout.addWidget(self.progress_label)
        self.layout.addWidget(self.prompt_label)
        self.layout.addWidget(self.answer_input)
        self.layout.addWidget(self.feedback_label)
        self.layout.addWidget(self.correct_answer_label)
        self.layout.addWidget(self.submit_button)
        
        # Signal connection
        self.submit_button.clicked.connect(self.handle_submission)
        self.answer_input.returnPressed.connect(self.handle_submission)

        self.is_showing_feedback = False
        self.show_next_question()

    def show_next_question(self):
        # If you have answered all the questions and there are no more wrong answers
        if not self.remaining_questions and not self.mistakes:
            self.show_final_screen()
            return
        
        # If the round is over but there are still wrong answers, start over with the wrong answers.
        if not self.remaining_questions:
            self.remaining_questions = list(self.mistakes)
            random.shuffle(self.remaining_questions)
            self.mistakes = []
            
        self.is_showing_feedback = False
        self.q, self.a = self.remaining_questions[0]

        # Update interface
        total = len(self.all_questions)
        remaining = len(self.remaining_questions) + len(self.mistakes)
        self.progress_label.setText(f"Right: {self.correct_count}/{total} | Remaining: {remaining}")
        self.prompt_label.setText(f"<b>Please enter a definition for:</b><br>{self.q}")
        
        self.answer_input.clear()
        self.answer_input.setReadOnly(False)
        self.answer_input.setFocus()
        
        self.feedback_label.clear()
        self.correct_answer_label.clear()
        
        self.submit_button.setText("Answer")

    def handle_submission(self):
        if self.is_showing_feedback:
            self.show_next_question()
            return

        user_answer = self.answer_input.text()
        if not user_answer.strip():
            return
        
        # Compare answers
        if normalize_string(user_answer) == normalize_string(self.a):
            # CORRECT ANSWER
            self.feedback_label.setText("<b style='color: green;'>Correct!</b>")
            self.correct_count += 1
            # Remove question from current list
            self.remaining_questions.pop(0)
        else:
            # WRONG ANSWER
            self.feedback_label.setText("<b style='color: red;'>Wrong.</b>")
            self.correct_answer_label.setText(f"<b>Correct answer:</b><br>{self.a}")
            # Thêm câu này vào danh sách cần ôn lại
            self.mistakes.append((self.q, self.a))
            # Remove questions from the current list so they don't repeat immediately
            self.remaining_questions.pop(0)

        self.is_showing_feedback = True
        self.answer_input.setReadOnly(True)
        self.submit_button.setText("Continue")
        self.submit_button.setFocus()

    def show_final_screen(self):
        # Xóa các widget cũ
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)
        
        # Hiển thị thông báo hoàn thành
        self.layout.addWidget(QLabel("<h2>Congratulations!</h2>You have completed the session.."))
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        self.layout.addWidget(close_button)

def on_written_mode_triggered(browser):
    selected_nids = browser.selected_notes()
    if not selected_nids:
        showInfo("Select some tabs in your browser to get started.")
        return

    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    
    max_notes = len(selected_nids)
    config_dialog = ConfigDialog(field_names, browser, max_num=max_notes)
    if not config_dialog.exec():
        return

    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        if q_field in note and a_field in note and note[q_field].strip() and note[a_field].strip():
            questions.append((note[q_field], note[a_field]))

    if not questions:
        showInfo("No valid tags were found. Make sure the fields you selected are not empty.")
        return

    # Show quiz dialog
    dialog = WrittenDialog(questions, mw)
    dialog.exec()