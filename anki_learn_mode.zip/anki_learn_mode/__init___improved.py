# __init__.py
# Anki Learn Mode Add-on - Enhanced Version
# Cải tiến cả hai chế độ Multiple Choice và Written Mode

import os
import random
import re
import time
from unicodedata import normalize
from typing import List, Tuple, Dict

from aqt import mw, gui_hooks
from aqt.qt import (
    QAction,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QButtonGroup,
    QRadioButton,
    QComboBox,
    QSpinBox,
    QDialogButtonBox,
    QLineEdit,
    QMenu,
    QCheckBox,
    QTextEdit,
    QProgressBar,
    QGroupBox,
    QFrame,
    QTimer,
    QSlider,
    Qt,
)
from aqt.utils import showInfo, showWarning, tooltip
from anki.utils import strip_html

# --- PART 1: ENHANCED CONFIGURATION DIALOG ---
class EnhancedConfigDialog(QDialog):
    """Enhanced dialog for users to configure learning session."""
    def __init__(self, field_names, parent=None, default_num=10, max_num=100):
        super().__init__(parent)
        self.setWindowTitle("Enhanced Learn Mode Configuration")
        self.setMinimumSize(450, 400)
        self.layout = QVBoxLayout(self)
        
        # Field selection
        field_group = QGroupBox("Field Selection")
        field_layout = QVBoxLayout(field_group)
        
        field_layout.addWidget(QLabel("Select field for Question (Front):"))
        self.q_field_combo = QComboBox()
        self.q_field_combo.addItems(field_names)
        field_layout.addWidget(self.q_field_combo)
        
        field_layout.addWidget(QLabel("Select field for Answer (Back):"))
        self.a_field_combo = QComboBox()
        self.a_field_combo.addItems(field_names)
        if len(field_names) > 1:
            self.a_field_combo.setCurrentIndex(1)
        field_layout.addWidget(self.a_field_combo)
        
        self.layout.addWidget(field_group)
        
        # Session settings
        session_group = QGroupBox("Session Settings")
        session_layout = QVBoxLayout(session_group)
        
        session_layout.addWidget(QLabel("Number of cards to practice:"))
        self.num_questions_spin = QSpinBox()
        self.num_questions_spin.setMinimum(1)
        self.num_questions_spin.setMaximum(max_num)
        self.num_questions_spin.setValue(min(default_num, max_num))
        session_layout.addWidget(self.num_questions_spin)
        
        # Difficulty settings
        self.shuffle_options = QCheckBox("Shuffle answer options (Multiple Choice)")
        self.shuffle_options.setChecked(True)
        session_layout.addWidget(self.shuffle_options)
        
        self.case_sensitive = QCheckBox("Case sensitive answers (Written Mode)")
        self.case_sensitive.setChecked(False)
        session_layout.addWidget(self.case_sensitive)
        
        self.partial_match = QCheckBox("Allow partial matches (Written Mode)")
        self.partial_match.setChecked(True)
        session_layout.addWidget(self.partial_match)
        
        self.show_hints = QCheckBox("Show hints in Written Mode")
        self.show_hints.setChecked(True)
        session_layout.addWidget(self.show_hints)
        
        self.layout.addWidget(session_group)
        
        # Buttons
        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.layout.addWidget(self.button_box)
        
        self.config = None
        
    def accept(self):
        q_field = self.q_field_combo.currentText()
        a_field = self.a_field_combo.currentText()
        if q_field == a_field:
            showWarning("Question and answer fields must not be the same.")
            return
        
        self.config = {
            "q_field": q_field,
            "a_field": a_field,
            "num_questions": self.num_questions_spin.value(),
            "shuffle_options": self.shuffle_options.isChecked(),
            "case_sensitive": self.case_sensitive.isChecked(),
            "partial_match": self.partial_match.isChecked(),
            "show_hints": self.show_hints.isChecked()
        }
        super().accept()

# --- PART 2: ENHANCED MULTIPLE CHOICE MODE ---
class EnhancedMultipleChoiceDialog(QDialog):
    """Enhanced Multiple Choice dialog with improved features."""
    
    def __init__(self, questions, config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Enhanced Learn Mode - Multiple Choice")
        self.setMinimumSize(500, 400)
        self.layout = QVBoxLayout(self)
        
        self.questions = questions
        self.config = config
        self.all_answers = list(set([a for q, a in self.questions]))
        self.current_q_index = 0
        self.score = 0
        self.start_time = time.time()
        self.question_times = []
        self.answered_correctly = []
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(len(self.questions))
        self.progress_bar.setValue(0)
        self.layout.addWidget(self.progress_bar)
        
        # Score and timer display
        self.stats_layout = QHBoxLayout()
        self.score_label = QLabel(f"Score: {self.score}/{len(self.questions)}")
        self.time_label = QLabel("Time: 00:00")
        self.accuracy_label = QLabel("Accuracy: 0%")
        self.stats_layout.addWidget(self.score_label)
        self.stats_layout.addWidget(self.time_label)
        self.stats_layout.addWidget(self.accuracy_label)
        self.layout.addLayout(self.stats_layout)
        
        # Question area
        self.question_label = QLabel()
        self.question_label.setWordWrap(True)
        self.question_label.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid gray;")
        self.layout.addWidget(self.question_label)
        
        # Options
        self.options_group = QButtonGroup(self)
        self.radio_buttons = [QRadioButton() for _ in range(4)]
        for i, rb in enumerate(self.radio_buttons):
            rb.setStyleSheet("font-size: 12px; padding: 5px;")
            self.layout.addWidget(rb)
            self.options_group.addButton(rb)
        
        # Feedback area
        self.feedback_label = QLabel()
        self.feedback_label.setWordWrap(True)
        self.feedback_label.setStyleSheet("font-size: 12px; padding: 5px;")
        self.layout.addWidget(self.feedback_label)
        
        # Buttons
        self.button_layout = QHBoxLayout()
        self.submit_button = QPushButton("Submit Answer")
        self.submit_button.clicked.connect(self.check_answer)
        self.submit_button.setStyleSheet("font-weight: bold; padding: 8px;")
        
        self.next_button = QPushButton("Next Question")
        self.next_button.clicked.connect(self.next_question)
        self.next_button.setStyleSheet("font-weight: bold; padding: 8px;")
        
        self.hint_button = QPushButton("Show Hint")
        self.hint_button.clicked.connect(self.show_hint)
        
        self.button_layout.addWidget(self.submit_button)
        self.button_layout.addWidget(self.next_button)
        self.button_layout.addWidget(self.hint_button)
        self.layout.addLayout(self.button_layout)
        
        # Timer for updating display
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)  # Update every second
        
        self.show_question()
        
    def update_timer(self):
        elapsed = int(time.time() - self.start_time)
        minutes = elapsed // 60
        seconds = elapsed % 60
        self.time_label.setText(f"Time: {minutes:02d}:{seconds:02d}")
        
    def show_question(self):
        if self.current_q_index >= len(self.questions):
            self.show_final_score()
            return
            
        self.question_start_time = time.time()
        self.feedback_label.setText("")
        self.submit_button.show()
        self.next_button.hide()
        self.hint_button.show()
        
        # Reset radio buttons
        for rb in self.radio_buttons:
            rb.setEnabled(True)
            rb.setStyleSheet("font-size: 12px; padding: 5px;")
        self.options_group.setExclusive(False)
        for rb in self.radio_buttons:
            rb.setChecked(False)
        self.options_group.setExclusive(True)
        
        # Update progress
        self.progress_bar.setValue(self.current_q_index)
        
        q_text, correct_answer = self.questions[self.current_q_index]
        self.question_label.setText(
            f"<b>Question {self.current_q_index + 1}/{len(self.questions)}:</b><br><br>{q_text}"
        )
        
        # Generate options
        options = {correct_answer}
        possible_wrong_answers = [ans for ans in self.all_answers if ans != correct_answer]
        num_to_sample = min(len(possible_wrong_answers), 3)
        if num_to_sample > 0:
            options.update(random.sample(possible_wrong_answers, num_to_sample))
        
        while len(options) < min(4, len(self.all_answers)):
            options.add(random.choice(self.all_answers))
            
        options_list = list(options)
        if self.config["shuffle_options"]:
            random.shuffle(options_list)
        
        for i, rb in enumerate(self.radio_buttons):
            if i < len(options_list):
                rb.setText(options_list[i])
                rb.show()
            else:
                rb.hide()
                
    def show_hint(self):
        """Show a hint for the current question."""
        _, correct_answer = self.questions[self.current_q_index]
        hint_length = max(1, len(correct_answer) // 3)
        hint = correct_answer[:hint_length] + "..."
        tooltip(f"Hint: Answer starts with '{hint}'")
        
    def check_answer(self):
        checked_button = self.options_group.checkedButton()
        if not checked_button:
            tooltip("Please select an answer.")
            return
            
        # Record time taken
        time_taken = time.time() - self.question_start_time
        self.question_times.append(time_taken)
        
        user_answer = checked_button.text()
        _, correct_answer = self.questions[self.current_q_index]
        
        # Disable all buttons
        for rb in self.radio_buttons:
            rb.setEnabled(False)
            
        is_correct = user_answer == correct_answer
        self.answered_correctly.append(is_correct)
        
        if is_correct:
            self.score += 1
            self.feedback_label.setText(
                f"<b style='color: green;'>✓ Correct!</b><br>Time: {time_taken:.1f}s"
            )
            checked_button.setStyleSheet("color: green; font-weight: bold; font-size: 12px; padding: 5px;")
        else:
            self.feedback_label.setText(
                f"<b style='color: red;'>✗ Incorrect!</b><br>"
                f"The correct answer is: <b>{correct_answer}</b><br>Time: {time_taken:.1f}s"
            )
            checked_button.setStyleSheet("color: red; font-size: 12px; padding: 5px;")
            # Highlight correct answer
            for rb in self.radio_buttons:
                if rb.text() == correct_answer:
                    rb.setStyleSheet("color: green; font-weight: bold; font-size: 12px; padding: 5px;")
                    break
                    
        # Update statistics
        accuracy = (self.score / (self.current_q_index + 1)) * 100
        self.score_label.setText(f"Score: {self.score}/{len(self.questions)}")
        self.accuracy_label.setText(f"Accuracy: {accuracy:.1f}%")
        
        self.submit_button.hide()
        self.next_button.show()
        self.hint_button.hide()
        self.next_button.setFocus()
        
    def next_question(self):
        self.current_q_index += 1
        self.show_question()
        
    def show_final_score(self):
        self.timer.stop()
        
        # Clear layout
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            if item.widget():
                item.widget().setParent(None)
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().setParent(None)
                item.layout().deleteLater()
        
        # Calculate statistics
        total_time = sum(self.question_times)
        avg_time = total_time / len(self.question_times) if self.question_times else 0
        accuracy = (self.score / len(self.questions)) * 100
        
        # Create results display
        results_text = f"""
        <h2>📊 Session Complete!</h2>
        <h3>Your Results:</h3>
        <p><b>Score:</b> {self.score}/{len(self.questions)} ({accuracy:.1f}%)</p>
        <p><b>Total Time:</b> {int(total_time//60):02d}:{int(total_time%60):02d}</p>
        <p><b>Average Time per Question:</b> {avg_time:.1f}s</p>
        """
        
        if accuracy >= 90:
            results_text += "<p style='color: gold;'><b>🏆 Excellent! Outstanding performance!</b></p>"
        elif accuracy >= 80:
            results_text += "<p style='color: green;'><b>🎉 Great job! Well done!</b></p>"
        elif accuracy >= 70:
            results_text += "<p style='color: blue;'><b>👍 Good work! Keep practicing!</b></p>"
        else:
            results_text += "<p style='color: orange;'><b>💪 Keep practicing! You'll improve!</b></p>"
            
        self.layout.addWidget(QLabel(results_text))
        
        # Button layout for Close and Restart
        button_layout = QHBoxLayout()
        
        # Restart button
        restart_button = QPushButton("🔄 Restart Quiz")
        restart_button.clicked.connect(self.restart_quiz)
        restart_button.setStyleSheet("font-weight: bold; padding: 10px; background-color: #4CAF50; color: white;")
        button_layout.addWidget(restart_button)
        
        # Close button
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        close_button.setStyleSheet("font-weight: bold; padding: 10px;")
        button_layout.addWidget(close_button)
        
        self.layout.addLayout(button_layout)
        
    def restart_quiz(self):
        """Restart the quiz with the same questions and config."""
        self.accept()  # Close current dialog
        # Create new dialog with same questions and config
        dialog = EnhancedMultipleChoiceDialog(self.questions, self.config, self.parent())
        dialog.exec()

# --- PART 3: ENHANCED WRITTEN MODE ---
def normalize_string(s: str, case_sensitive: bool = False) -> str:
    """Enhanced string normalization."""
    normalized = normalize("NFC", s).strip()
    if not case_sensitive:
        normalized = normalized.lower()
    return normalized

def calculate_similarity(s1: str, s2: str) -> float:
    """Calculate similarity between two strings using simple ratio."""
    if s1 == s2:
        return 1.0
    
    # Simple similarity based on character overlap
    longer = s1 if len(s1) > len(s2) else s2
    shorter = s2 if len(s1) > len(s2) else s1
    
    if len(longer) == 0:
        return 1.0
        
    matches = sum(c1 == c2 for c1, c2 in zip(longer, shorter))
    return matches / len(longer)

class EnhancedWrittenDialog(QDialog):
    """Enhanced Written dialog with improved features."""
    
    def __init__(self, questions, config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Enhanced Learn Mode - Written")
        self.setMinimumSize(500, 450)
        self.layout = QVBoxLayout(self)
        
        self.all_questions = questions
        self.config = config
        self.remaining_questions = list(self.all_questions)
        random.shuffle(self.remaining_questions)
        
        self.correct_on_first_try = 0
        self.mistakes = []
        self.current_attempts = 0
        self.max_attempts = 3
        self.start_time = time.time()
        self.question_times = []
        
        self.is_showing_feedback = False
        self.first_attempt = True
        
        # Progress bar
        self.progress_bar = QProgressBar()
        total_questions = len(self.all_questions)
        self.progress_bar.setMaximum(total_questions)
        self.progress_bar.setValue(0)
        self.layout.addWidget(self.progress_bar)
        
        # Statistics
        self.stats_layout = QHBoxLayout()
        self.progress_label = QLabel()
        self.time_label = QLabel("Time: 00:00")
        self.accuracy_label = QLabel("Accuracy: 0%")
        self.stats_layout.addWidget(self.progress_label)
        self.stats_layout.addWidget(self.time_label)
        self.stats_layout.addWidget(self.accuracy_label)
        self.layout.addLayout(self.stats_layout)
        
        # Question area
        self.prompt_label = QLabel()
        self.prompt_label.setWordWrap(True)
        self.prompt_label.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid gray;")
        self.layout.addWidget(self.prompt_label)
        
        # Hint area
        self.hint_label = QLabel()
        self.hint_label.setWordWrap(True)
        self.hint_label.setStyleSheet("font-size: 11px; color: blue; font-style: italic;")
        self.layout.addWidget(self.hint_label)
        
        # Answer input
        self.answer_input = QLineEdit()
        self.answer_input.setStyleSheet("font-size: 14px; padding: 8px;")
        self.answer_input.setPlaceholderText("Type your answer here...")
        self.layout.addWidget(self.answer_input)
        
        # Feedback area
        self.feedback_label = QLabel()
        self.feedback_label.setWordWrap(True)
        self.layout.addWidget(self.feedback_label)
        
        self.correct_answer_label = QLabel()
        self.correct_answer_label.setWordWrap(True)
        self.correct_answer_label.setStyleSheet("font-weight: bold; color: green;")
        self.layout.addWidget(self.correct_answer_label)
        
        # Buttons
        self.button_layout = QHBoxLayout()
        self.submit_button = QPushButton("Submit Answer")
        self.submit_button.setStyleSheet("font-weight: bold; padding: 8px;")
        
        self.reveal_button = QPushButton("Show Answer")
        self.reveal_button.setStyleSheet("padding: 8px;")
        
        self.hint_button = QPushButton("Get Hint")
        self.hint_button.setStyleSheet("padding: 8px;")
        
        self.button_layout.addWidget(self.submit_button)
        self.button_layout.addWidget(self.reveal_button)
        self.button_layout.addWidget(self.hint_button)
        self.layout.addLayout(self.button_layout)
        
        # Connect signals
        self.submit_button.clicked.connect(self.handle_submission)
        self.reveal_button.clicked.connect(self.reveal_answer)
        self.hint_button.clicked.connect(self.show_hint)
        self.answer_input.returnPressed.connect(self.handle_submission)
        
        # Timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)
        
        self.show_next_question()
        
    def update_timer(self):
        elapsed = int(time.time() - self.start_time)
        minutes = elapsed // 60
        seconds = elapsed % 60
        self.time_label.setText(f"Time: {minutes:02d}:{seconds:02d}")
        
    def show_next_question(self):
        if not self.remaining_questions and not self.mistakes:
            self.show_final_screen()
            return
            
        if not self.remaining_questions:
            # Move to review mode
            self.remaining_questions = list(self.mistakes)
            random.shuffle(self.remaining_questions)
            self.mistakes = []
            
        self.is_showing_feedback = False
        self.first_attempt = True
        self.current_attempts = 0
        self.question_start_time = time.time()
        
        self.q, self.a = self.remaining_questions[0]
        
        # Update progress
        completed = len(self.all_questions) - len(self.remaining_questions) - len(self.mistakes)
        self.progress_bar.setValue(completed)
        
        total = len(self.all_questions)
        remaining = len(self.remaining_questions) + len(self.mistakes)
        accuracy = (self.correct_on_first_try / max(1, completed)) * 100 if completed > 0 else 0
        
        self.progress_label.setText(f"Correct first try: {self.correct_on_first_try}/{total} | Remaining: {remaining}")
        self.accuracy_label.setText(f"Accuracy: {accuracy:.1f}%")
        
        self.prompt_label.setText(f"<b>Enter the definition for:</b><br><br>{self.q}")
        
        self.answer_input.clear()
        self.answer_input.setReadOnly(False)
        self.answer_input.setFocus()
        
        self.feedback_label.clear()
        self.correct_answer_label.clear()
        self.hint_label.clear()
        
        self.submit_button.setText("Submit Answer")
        self.submit_button.show()
        self.reveal_button.show()
        if self.config["show_hints"]:
            self.hint_button.show()
        else:
            self.hint_button.hide()
            
    def show_hint(self):
        """Show progressive hints."""
        if not self.config["show_hints"]:
            return
            
        hint_texts = []
        answer = self.a
        
        # Hint 1: Length
        hint_texts.append(f"💡 The answer has {len(answer)} characters")
        
        # Hint 2: First few characters
        if len(answer) > 3:
            hint_texts.append(f"💡 The answer starts with: {answer[:2]}...")
        
        # Hint 3: Pattern
        if len(answer) > 5:
            pattern = ""
            for i, char in enumerate(answer):
                if i < 2 or i >= len(answer) - 1:
                    pattern += char
                else:
                    pattern += "_"
            hint_texts.append(f"💡 Pattern: {pattern}")
            
        # Show progressive hints based on attempts
        if self.current_attempts < len(hint_texts):
            hint_text = "<br>".join(hint_texts[:self.current_attempts + 1])
            self.hint_label.setText(hint_text)
            
    def handle_submission(self):
        if self.is_showing_feedback:
            self.show_next_question()
            return
            
        user_answer = self.answer_input.text().strip()
        if not user_answer:
            tooltip("Please enter an answer.")
            return
            
        self.current_attempts += 1
        
        # Normalize answers for comparison
        normalized_user = normalize_string(user_answer, self.config["case_sensitive"])
        normalized_correct = normalize_string(self.a, self.config["case_sensitive"])
        
        is_correct = normalized_user == normalized_correct
        
        # Check for partial match if enabled
        is_partial_match = False
        if not is_correct and self.config["partial_match"]:
            similarity = calculate_similarity(normalized_user, normalized_correct)
            is_partial_match = similarity >= 0.8  # 80% similarity threshold
            
        if is_correct:
            # Record time
            time_taken = time.time() - self.question_start_time
            self.question_times.append(time_taken)
            
            self.feedback_label.setText(
                f"<b style='color: green;'>✓ Correct!</b><br>Time: {time_taken:.1f}s"
            )
            if self.first_attempt:
                self.correct_on_first_try += 1
                
            self.remaining_questions.pop(0)
            self.prepare_for_next_question()
            
        elif is_partial_match:
            self.feedback_label.setText(
                f"<b style='color: orange;'>Close! Your answer is very similar.</b><br>"
                f"Try to be more precise. (Attempt {self.current_attempts}/{self.max_attempts})"
            )
            if self.current_attempts >= self.max_attempts:
                self.reveal_answer()
            else:
                self.answer_input.selectAll()
                self.show_hint()
                
        else:
            if self.first_attempt:
                self.first_attempt = False
                if (self.q, self.a) not in self.mistakes:
                    self.mistakes.append((self.q, self.a))
                    
            if self.current_attempts >= self.max_attempts:
                self.reveal_answer()
            else:
                self.feedback_label.setText(
                    f"<b style='color: red;'>Not correct.</b> "
                    f"Try again or reveal the answer. (Attempt {self.current_attempts}/{self.max_attempts})"
                )
                self.answer_input.selectAll()
                self.show_hint()
                
    def reveal_answer(self):
        """Show the correct answer."""
        time_taken = time.time() - self.question_start_time
        self.question_times.append(time_taken)
        
        self.feedback_label.setText(f"<b style='color: red;'>Revealed</b><br>Time: {time_taken:.1f}s")
        self.correct_answer_label.setText(f"<b>Correct answer:</b><br>{self.a}")
        
        if (self.q, self.a) not in self.mistakes:
            self.mistakes.append((self.q, self.a))
            
        self.remaining_questions.pop(0)
        self.prepare_for_next_question()
        
    def prepare_for_next_question(self):
        """Prepare UI for next question."""
        self.is_showing_feedback = True
        self.answer_input.setReadOnly(True)
        
        self.submit_button.setText("Next Question")
        self.submit_button.setFocus()
        self.reveal_button.hide()
        self.hint_button.hide()
        
    def show_final_screen(self):
        self.timer.stop()
        
        # Clear layout
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            if item.widget():
                item.widget().setParent(None)
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().setParent(None)
                item.layout().deleteLater()
        
        # Calculate statistics
        total_time = sum(self.question_times)
        avg_time = total_time / len(self.question_times) if self.question_times else 0
        accuracy = (self.correct_on_first_try / len(self.all_questions)) * 100
        
        results_text = f"""
        <h2>🎉 Session Complete!</h2>
        <h3>Your Results:</h3>
        <p><b>First-try Correct:</b> {self.correct_on_first_try}/{len(self.all_questions)} ({accuracy:.1f}%)</p>
        <p><b>Total Time:</b> {int(total_time//60):02d}:{int(total_time%60):02d}</p>
        <p><b>Average Time per Question:</b> {avg_time:.1f}s</p>
        """
        
        if accuracy >= 90:
            results_text += "<p style='color: gold;'><b>🏆 Excellent! Outstanding performance!</b></p>"
        elif accuracy >= 80:
            results_text += "<p style='color: green;'><b>🎉 Great job! Well done!</b></p>"
        elif accuracy >= 70:
            results_text += "<p style='color: blue;'><b>👍 Good work! Keep practicing!</b></p>"
        else:
            results_text += "<p style='color: orange;'><b>💪 Keep practicing! You'll improve!</b></p>"
            
        self.layout.addWidget(QLabel(results_text))
        
        # Button layout for Close and Restart
        button_layout = QHBoxLayout()
        
        # Restart button
        restart_button = QPushButton("🔄 Restart Practice")
        restart_button.clicked.connect(self.restart_practice)
        restart_button.setStyleSheet("font-weight: bold; padding: 10px; background-color: #4CAF50; color: white;")
        button_layout.addWidget(restart_button)
        
        # Close button
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        close_button.setStyleSheet("font-weight: bold; padding: 10px;")
        button_layout.addWidget(close_button)
        
        self.layout.addLayout(button_layout)
        
    def restart_practice(self):
        """Restart the practice with the same questions and config."""
        self.accept()  # Close current dialog
        # Create new dialog with same questions and config
        dialog = EnhancedWrittenDialog(self.all_questions, self.config, self.parent())
        dialog.exec()

# --- PART 4: TRIGGER FUNCTIONS ---
def on_enhanced_multiple_choice_triggered(browser):
    """Launch enhanced multiple choice mode."""
    selected_nids = browser.selected_notes()
    if len(selected_nids) < 4:
        showInfo(f"At least 4 cards must be selected to create a quiz. You have only selected {len(selected_nids)} cards.")
        return
        
    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    max_notes = len(selected_nids)
    
    config_dialog = EnhancedConfigDialog(field_names, browser, default_num=10, max_num=max_notes)
    if not config_dialog.exec():
        return
        
    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    
    if num_questions < 4:
        showInfo("Multiple choice mode requires at least 4 questions.")
        return
        
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        q_text = strip_html(note[q_field])
        a_text = strip_html(note[a_field])
        if q_text.strip() and a_text.strip():
            questions.append((q_text, a_text))
            
    if len(questions) < 4:
        showInfo(f"Cannot create quiz. Only found {len(questions)} valid cards (at least 4 required). Make sure your selected fields are not empty.")
        return
        
    dialog = EnhancedMultipleChoiceDialog(questions, config, mw)
    dialog.exec()

def on_enhanced_written_mode_triggered(browser):
    """Launch enhanced written mode."""
    selected_nids = browser.selected_notes()
    if not selected_nids:
        showInfo("Please select some cards in the browser to start.")
        return
        
    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    max_notes = len(selected_nids)
    
    config_dialog = EnhancedConfigDialog(field_names, browser, default_num=10, max_num=max_notes)
    if not config_dialog.exec():
        return
        
    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        q_text = strip_html(note[q_field])
        a_text = strip_html(note[a_field])
        if q_text.strip() and a_text.strip():
            questions.append((q_text, a_text))
            
    if not questions:
        showInfo("No valid cards found. Make sure your selected fields are not empty.")
        return
        
    dialog = EnhancedWrittenDialog(questions, config, mw)
    dialog.exec()

# --- PART 5: MENU CREATION ---
def add_enhanced_learn_mode_menu(browser):
    """Add enhanced learn mode menu to browser."""
    menu_name = "enhancedLearnModeMenu"
    menu = browser.form.menubar.findChild(QMenu, menu_name)
    if not menu:
        menu = browser.form.menubar.addMenu("🎓 Enhanced Learn Mode")
        menu.setObjectName(menu_name)
    menu.clear()
    
    # Enhanced Multiple Choice
    mc_action = QAction("🎯 Enhanced Multiple Choice...", browser)
    mc_action.triggered.connect(lambda: on_enhanced_multiple_choice_triggered(browser))
    menu.addAction(mc_action)
    
    # Enhanced Written Mode
    written_action = QAction("✍️ Enhanced Written Mode...", browser)
    written_action.triggered.connect(lambda: on_enhanced_written_mode_triggered(browser))
    menu.addAction(written_action)

# Register the menu
gui_hooks.browser_menus_did_init.append(add_enhanced_learn_mode_menu)
