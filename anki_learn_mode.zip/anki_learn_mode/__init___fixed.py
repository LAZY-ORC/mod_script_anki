# __init__.py
# Anki Learn Mode Add-on - Enhanced Fixed Version
# Cải tiến cả hai chế độ Multiple Choice và Written Mode với nhiều tính năng mới

import os
import random
import re
import time
from unicodedata import normalize
from typing import List, Tuple, Dict

from aqt import mw, gui_hooks
from aqt.qt import (
    QAction,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QButtonGroup,
    QRadioButton,
    QComboBox,
    QSpinBox,
    QDialogButtonBox,
    QLineEdit,
    QMenu,
    QCheckBox,
    QTextEdit,
    QProgressBar,
    QGroupBox,
    QFrame,
    QTimer,
    QSlider,
    Qt,
)
from aqt.utils import showInfo, showWarning, tooltip

# --- PART 1: CONFIGURATION DIALOG (Unchanged) ---
# ... (Keep all code of ConfigDialog unchanged) ---
class ConfigDialog(QDialog):
    """Dialog for users to select fields and number of questions."""
    def __init__(self, field_names, parent=None, default_num=10, max_num=100):
        super().__init__(parent)
        self.setWindowTitle("Learn Mode Configuration")
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(QLabel("Select field for Question (Front):"))
        self.q_field_combo = QComboBox()
        self.q_field_combo.addItems(field_names)
        self.layout.addWidget(self.q_field_combo)
        self.layout.addWidget(QLabel("Select field for Answer (Back):"))
        self.a_field_combo = QComboBox()
        self.a_field_combo.addItems(field_names)
        if len(field_names) > 1:
            self.a_field_combo.setCurrentIndex(1)
        self.layout.addWidget(self.a_field_combo)
        self.layout.addWidget(QLabel("Number of cards to practice:"))
        self.num_questions_spin = QSpinBox()
        self.num_questions_spin.setMinimum(1)
        self.num_questions_spin.setMaximum(max_num)
        self.num_questions_spin.setValue(min(default_num, max_num))
        self.layout.addWidget(self.num_questions_spin)
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.layout.addWidget(self.button_box)
        self.config = None
        
    def accept(self):
        q_field = self.q_field_combo.currentText()
        a_field = self.a_field_combo.currentText()
        if q_field == a_field:
            showWarning("Question and answer fields must not be the same.")
            return
        self.config = {"q_field": q_field, "a_field": a_field, "num_questions": self.num_questions_spin.value()}
        super().accept()

# --- PART 2: MULTIPLE CHOICE MODE (Unchanged) ---
# ... (Keep all code of MultipleChoiceDialog and on_multiple_choice_triggered) ---
class MultipleChoiceDialog(QDialog):
    def __init__(self, questions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Learn Mode - Multiple Choice")
        self.setMinimumSize(400, 300)
        self.layout = QVBoxLayout(self)
        self.questions = questions
        self.all_answers = list(set([a for q, a in self.questions]))
        self.current_q_index = 0
        self.score = 0
        self.question_label = QLabel()
        self.question_label.setWordWrap(True)
        self.layout.addWidget(self.question_label)
        self.options_group = QButtonGroup(self)
        self.radio_buttons = [QRadioButton() for _ in range(4)]
        for rb in self.radio_buttons:
            self.layout.addWidget(rb)
            self.options_group.addButton(rb)
        self.feedback_label = QLabel()
        self.layout.addWidget(self.feedback_label)
        self.button_layout = QHBoxLayout()
        self.submit_button = QPushButton("Submit")
        self.submit_button.clicked.connect(self.check_answer)
        self.next_button = QPushButton("Next")
        self.next_button.clicked.connect(self.next_question)
        self.button_layout.addWidget(self.submit_button)
        self.button_layout.addWidget(self.next_button)
        self.layout.addLayout(self.button_layout)
        self.show_question()
        
    def show_question(self):
        if self.current_q_index >= len(self.questions):
            self.show_final_score()
            return
        self.feedback_label.setText("")
        self.submit_button.show()
        self.next_button.hide()
        for rb in self.radio_buttons:
            rb.setEnabled(True)
            rb.setStyleSheet("")
        self.options_group.setExclusive(False)
        for rb in self.radio_buttons:
            rb.setChecked(False)
        self.options_group.setExclusive(True)
        q_text, correct_answer = self.questions[self.current_q_index]
        self.question_label.setText(f"<b>Question {self.current_q_index + 1}/{len(self.questions)}:</b><br>{q_text}")
        options = {correct_answer}
        possible_wrong_answers = [ans for ans in self.all_answers if ans != correct_answer]
        num_to_sample = min(len(possible_wrong_answers), 3)
        if num_to_sample > 0:
            options.update(random.sample(possible_wrong_answers, num_to_sample))
        while len(options) < min(4, len(self.all_answers)):
             options.add(random.choice(self.all_answers))
        options_list = list(options)
        random.shuffle(options_list)
        for i, rb in enumerate(self.radio_buttons):
            if i < len(options_list):
                rb.setText(options_list[i])
                rb.show()
            else:
                rb.hide()
                
    def check_answer(self):
        checked_button = self.options_group.checkedButton()
        if not checked_button:
            tooltip("Please select an answer.")
            return
        user_answer = checked_button.text()
        _, correct_answer = self.questions[self.current_q_index]
        for rb in self.radio_buttons:
            rb.setEnabled(False)
        if user_answer == correct_answer:
            self.score += 1
            self.feedback_label.setText("<b style='color: green;'>Correct!</b>")
            checked_button.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.feedback_label.setText(f"<b style='color: red;'>Incorrect!</b> The correct answer is: <b>{correct_answer}</b>")
            checked_button.setStyleSheet("color: red;")
            for rb in self.radio_buttons:
                if rb.text() == correct_answer:
                    rb.setStyleSheet("color: green; font-weight: bold;")
                    break
        self.submit_button.hide()
        self.next_button.show()
        self.next_button.setFocus()
        
    def next_question(self):
        self.current_q_index += 1
        self.show_question()
        
    def show_final_score(self):
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            if item.widget():
                item.widget().setParent(None)
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().setParent(None)
                item.layout().deleteLater()
        score_text = f"Completed!\nYour score: {self.score}/{len(self.questions)}"
        self.layout.addWidget(QLabel(score_text))
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        self.layout.addWidget(close_button)

def on_multiple_choice_triggered(browser):
    selected_nids = browser.selected_notes()
    if len(selected_nids) < 4:
        showInfo(f"At least 4 cards must be selected to create a quiz. You have only selected {len(selected_nids)} cards.")
        return
    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    max_notes = len(selected_nids)
    config_dialog = ConfigDialog(field_names, browser, default_num=10, max_num=max_notes)
    if not config_dialog.exec():
        return
    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    if num_questions < 4:
        showInfo("Multiple choice mode requires at least 4 questions.")
        return
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        if q_field in note and a_field in note and note[q_field].strip() and note[a_field].strip():
            questions.append((note[q_field], note[a_field]))
    if len(questions) < 4:
        showInfo(f"Cannot create quiz. Only found {len(questions)} valid cards (at least 4 required). Make sure your selected fields are not empty.")
        return
    dialog = MultipleChoiceDialog(questions, mw)
    dialog.exec()

# --- PART 3: WRITTEN MODE - MODIFIED ---

def normalize_string(s: str) -> str:
    return normalize("NFC", s).lower().strip()

class WrittenDialog(QDialog):
    """Dialog for "Written" learning mode with hint feature."""
    def __init__(self, questions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Learn Mode - Written")
        self.setMinimumSize(450, 250)
        self.layout = QVBoxLayout(self)

        self.all_questions = questions
        self.remaining_questions = list(self.all_questions)
        random.shuffle(self.remaining_questions)
        
        self.correct_on_first_try = 0
        self.mistakes = []

        # --- MODIFIED ---
        # Add new state variables
        self.is_showing_feedback = False # Waiting for "Next" button
        self.first_attempt = True      # Is this the first attempt for this question?

        # Widgets
        self.progress_label = QLabel()
        self.prompt_label = QLabel()
        self.prompt_label.setWordWrap(True)
        self.answer_input = QLineEdit()
        self.feedback_label = QLabel()
        self.correct_answer_label = QLabel()
        self.correct_answer_label.setWordWrap(True)

        # --- MODIFIED ---
        # Group buttons into a horizontal layout
        self.button_layout = QHBoxLayout()
        self.reveal_button = QPushButton("Reveal Answer")
        self.submit_button = QPushButton("Submit")
        self.button_layout.addWidget(self.reveal_button)
        self.button_layout.addWidget(self.submit_button)

        self.layout.addWidget(self.progress_label)
        self.layout.addWidget(self.prompt_label)
        self.layout.addWidget(self.answer_input)
        self.layout.addWidget(self.feedback_label)
        self.layout.addWidget(self.correct_answer_label)
        self.layout.addLayout(self.button_layout) # Add button layout
        
        # Connect signals
        self.submit_button.clicked.connect(self.handle_submission)
        self.reveal_button.clicked.connect(self.reveal_answer) # New button
        self.answer_input.returnPressed.connect(self.handle_submission)

        self.show_next_question()

    def show_next_question(self):
        if not self.remaining_questions and not self.mistakes:
            self.show_final_screen()
            return
        
        if not self.remaining_questions:
            self.remaining_questions = list(self.mistakes)
            random.shuffle(self.remaining_questions)
            self.mistakes = []
        
        # --- MODIFIED ---
        # Reset state for new question
        self.is_showing_feedback = False
        self.first_attempt = True
        self.q, self.a = self.remaining_questions[0]

        total = len(self.all_questions)
        remaining = len(self.remaining_questions) + len(self.mistakes)
        # Clarify variable name for score
        self.progress_label.setText(f"Correct first try: {self.correct_on_first_try}/{total} | Remaining: {remaining}")
        self.prompt_label.setText(f"<b>Please enter definition for:</b><br>{self.q}")
        
        self.answer_input.clear()
        self.answer_input.setReadOnly(False)
        self.answer_input.setFocus()
        
        self.feedback_label.clear()
        self.correct_answer_label.clear()
        
        self.submit_button.setText("Submit")
        self.reveal_button.hide() # Hide reveal answer button

    def handle_submission(self):
        if self.is_showing_feedback:
            self.show_next_question()
            return

        user_answer = self.answer_input.text()
        if not user_answer.strip():
            return
        
        is_correct = normalize_string(user_answer) == normalize_string(self.a)

        if is_correct:
            # --- MODIFIED ---
            # Correct answer
            self.feedback_label.setText("<b style='color: green;'>Correct!</b>")
            if self.first_attempt:
                self.correct_on_first_try += 1
            
            # Whether correct on first try or later, move to next question
            self.remaining_questions.pop(0)
            self.prepare_for_next_question()
        else:
            # --- MODIFIED ---
            # Incorrect answer
            if self.first_attempt:
                # First wrong attempt: gentle warning and allow retry
                self.first_attempt = False
                self.feedback_label.setText("<b style='color: orange;'>Not correct.</b> Try again or reveal the answer.")

                # Add this question to mistakes for later review
                # Even if user corrects on second try, still needs review
                self.mistakes.append((self.q, self.a))

                self.reveal_button.show() # Show reveal answer button
                self.answer_input.setFocus()
                self.answer_input.selectAll()
            else:
                # Still wrong on second try: show answer
                self.reveal_answer()

    def reveal_answer(self):
        """Show correct answer and prepare for next question."""
        self.feedback_label.setText("<b style='color: red;'>Incorrect.</b>")
        self.correct_answer_label.setText(f"<b>Correct answer:</b><br>{self.a}")
        
        # If question not in mistakes (e.g. user pressed "Reveal answer" immediately), add it.
        if (self.q, self.a) not in self.mistakes:
            self.mistakes.append((self.q, self.a))

        self.remaining_questions.pop(0)
        self.prepare_for_next_question()

    def prepare_for_next_question(self):
        """Lock inputs and change button to 'Next'."""
        self.is_showing_feedback = True
        self.answer_input.setReadOnly(True)
        self.submit_button.setText("Next")
        self.submit_button.setFocus()
        self.reveal_button.hide()

    def show_final_screen(self):
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            if item.widget():
                item.widget().setParent(None)
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().setParent(None)
                item.layout().deleteLater()
        
        self.layout.addWidget(QLabel("<h2>Congratulations!</h2>You have completed the session."))
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        self.layout.addWidget(close_button)

def on_written_mode_triggered(browser):
    # ... (Keep unchanged) ...
    selected_nids = browser.selected_notes()
    if not selected_nids:
        showInfo("Please select some cards in the browser to start.")
        return
    first_note = mw.col.get_note(selected_nids[0])
    field_names = first_note.keys()
    max_notes = len(selected_nids)
    config_dialog = ConfigDialog(field_names, browser, default_num=10, max_num=max_notes)
    if not config_dialog.exec():
        return
    config = config_dialog.config
    q_field, a_field, num_questions = config["q_field"], config["a_field"], config["num_questions"]
    random.shuffle(selected_nids)
    nids_to_use = selected_nids[:num_questions]
    questions = []
    notes = [mw.col.get_note(nid) for nid in nids_to_use]
    for note in notes:
        if q_field in note and a_field in note and note[q_field].strip() and note[a_field].strip():
            questions.append((note[q_field], note[a_field]))
    if not questions:
        showInfo("No valid cards found. Make sure your selected fields are not empty.")
        return
    dialog = WrittenDialog(questions, mw)
    dialog.exec()

# --- PART 4: CREATE MENU AND REGISTER HOOK (Unchanged) ---
# ... (Keep all code of add_learn_mode_menu unchanged) ---
def add_learn_mode_menu(browser):
    menu_name = "learnModeMenu"
    menu = browser.form.menubar.findChild(QMenu, menu_name)
    if not menu:
        menu = browser.form.menubar.addMenu("Learn Mode")
        menu.setObjectName(menu_name)
    menu.clear()
    mc_action = QAction("Learn: Multiple Choice...", browser)
    mc_action.triggered.connect(lambda: on_multiple_choice_triggered(browser))
    menu.addAction(mc_action)
    written_action = QAction("Learn: Written...", browser)
    written_action.triggered.connect(lambda: on_written_mode_triggered(browser))
    menu.addAction(written_action)

gui_hooks.browser_menus_did_init.append(add_learn_mode_menu)
